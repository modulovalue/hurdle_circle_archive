package com.modestasv.hurdlecircle.Interfaces;

/**
 * Wird benötigt um den Näherungssensor des Android Gerätes auszulesen
 */

public interface IProxable {
    public float getProx();
}
